## pyproject.py
![image](https://github.com/user-attachments/assets/ad1409fc-90be-4ee2-b520-dd7a2b80d2f1)
## plus.py
```
#더하기
import sys

def plus(a: int, b: int):
    print(a + b)

def main():
    args = sys.argv[1:]
    a, b = int(args[0]), int(args[1])
    plus(a, b)
```
## plus.py 결과
### pip install .
![image](https://github.com/user-attachments/assets/8916cdf6-db28-4847-b183-1be50cb6622d)
### python
![image](https://github.com/user-attachments/assets/22b03f79-326b-4507-99fb-e514518d9f48)
