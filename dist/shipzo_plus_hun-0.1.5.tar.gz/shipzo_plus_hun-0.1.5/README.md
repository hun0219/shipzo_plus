## pyproject.py
![image](https://github.com/user-attachments/assets/aca44e6e-42d1-42b4-bebf-3d2b9b752202)
## plus.py
```
#더하기
import sys

def plus(a: int, b: int):
    print(a + b)

def main():
    args = sys.argv[1:]
    a, b = int(args[0]), int(args[1])
    plus(a, b)
```
## plus.py 결과
### pip install .
![image](https://github.com/user-attachments/assets/f23402c7-5c92-4920-8b28-1c9250fb5fab)
### python
![image](https://github.com/user-attachments/assets/22b03f79-326b-4507-99fb-e514518d9f48)
