#더하기
import sys

def plus():
    a = sys.argv[1]
    b = sys.argv[2]
    print(int(a) + int(b))
