## pyproject.py
![image](https://github.com/user-attachments/assets/ff31d59b-bd25-4ec2-99b8-55e01ac7f1be)
## plus.py
```
import sys

def plus(a, b):
    return a + b

def main():
    args = sys.argv[1:]
    a = int(args[0])
    b = int(args[1])
    print(plus(a, b))
```
## plus.py 결과
![image](https://github.com/user-attachments/assets/22b03f79-326b-4507-99fb-e514518d9f48)
