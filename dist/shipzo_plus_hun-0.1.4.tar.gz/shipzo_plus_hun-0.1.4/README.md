## pyproject.py
![image](https://github.com/user-attachments/assets/f7ce440e-0812-45b5-8f69-387d44f9443c)
## plus.py
```
#더하기
import sys

def plus(a: int, b: int):
    print(a + b)

def main():
    args = sys.argv[1:]
    a, b = int(args[0]), int(args[1])
    plus(a, b)
```
## plus.py 결과
![image](https://github.com/user-attachments/assets/22b03f79-326b-4507-99fb-e514518d9f48)
