## pyproject.py
![image](https://github.com/user-attachments/assets/a3fef14e-0cc1-46ce-b3a3-eeb7aba16514)
## plus.py
```
#더하기
import sys

def plus():
    a = sys.argv[1]
    b = sys.argv[2]
    print(int(a) + int(b))
```
## plus.py 결과
![image](https://github.com/user-attachments/assets/22b03f79-326b-4507-99fb-e514518d9f48)
